# lnj-logistik sistem
Berikut repository demo tes program beserta file mysql

Demo Tes Program Programer Akhmad Hasan Arofid
