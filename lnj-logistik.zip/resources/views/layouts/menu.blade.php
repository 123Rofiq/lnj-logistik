<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link c-active" href="{{ route('home') }}">
        <i class="c-sidebar-nav-icon cil-home"></i>Home
    </a>
    <a class="c-sidebar-nav-link c-active" href="{{ route('customer.list') }}">
        <i class="c-sidebar-nav-icon fa fa-users"></i>Customer
    </a>
    <a class="c-sidebar-nav-link c-active" href="{{ route('container.list') }}">
        <i class="c-sidebar-nav-icon fa fa-solid fa fa-truck"></i>Container
    </a>
    <a class="c-sidebar-nav-link c-active" href="{{ route('transaksi.list') }}">
        <i class="c-sidebar-nav-icon fa fa-file" ></i> Transaction
        {{-- <i class="c-sidebar-nav-icon fa fa-exchange "></i>Transksi --}}
    </a>

</li>
