

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="fade-in">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between">
          <div>
          <h4 class="card-title mb-0">View Data Customer</h4>
          </div>
          <div class="btn-toolbar d-none d-md-block" role="toolbar" aria-label="Toolbar with buttons">
            
          <a href="<?php echo e(route('customer.list')); ?>" style="background-color: green;color:white" class="btn  active" > <span class="fa fa-list"></span> list CUSTOMER</a>
          </div>
          </div>
            <br>
        <div >
            <div class="form-group">
                <label for="">Name</label>
                <input type="text" readonly class="form-control" name="name" value="<?php echo e($customer->name); ?>">
                <font style="color:red"> <?php echo e($errors->has('name') ?  $errors->first('name') : ''); ?> </font>
              </div>
  
         
            <div class="form-group">
              <label for="">Email</label>
              <input type="email" readonly class="form-control" name="email" value="<?php echo e($customer->email); ?>">
              <font style="color:red"> <?php echo e($errors->has('email') ?  $errors->first('email') : ''); ?> </font>
            </div>
            <div class="form-group">
                <label for="">Address</label>
                <textarea class="form-control" 
                          name="alamat"
                          rows="3" readonly> <?php echo e($customer->alamat); ?></textarea>
                <font style="color:red"> <?php echo e($errors->has('alamat') ?  $errors->first('alamat') : ''); ?> </font>
              </div>
            <div class="form-group" style="margin-top: 24px;">
              <a href="<?php echo e(route('customer.list')); ?>" class="btn btn-success">Back</a>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lnj-logistik\resources\views/customer/view.blade.php ENDPATH**/ ?>