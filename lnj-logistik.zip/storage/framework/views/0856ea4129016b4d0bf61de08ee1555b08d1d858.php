

<?php 
use App\Container;
use App\Customer;
 $items = Customer::pluck('name', 'id');

$selectedID = 0;

$items_container = Container::pluck('janis', 'id');

$selected_container = 0;
?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="fade-in">
  <div class="card">
    <div class="card-body">
      <div class="d-flex justify-content-between">
        <div>
        <h4 class="card-title mb-0">Add Transaksi</h4>
        </div>
        <div class="btn-toolbar d-none d-md-block" role="toolbar" aria-label="Toolbar with buttons">
          
        <a href="<?php echo e(route('transaksi.list')); ?>" style="background-color: green;color:white" class="btn  active" > <span class="fa fa-list"></span> list Transaksi</a>
        </div>
        </div>
          <br>
          <?php if(session()->has('message')): ?>
          <p class="btn btn-success btn-block btn-sm custom_message text-left"><?php echo e(session()->get('message')); ?></p>
        <?php endif; ?>
          <form action="<?php echo e(route('transaksi.save')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-6">
                <div class="form-group">
                <label>Customer</label>
                <select class="form-control" name="customer_id">
                  <option>Select Customer</option>
                  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($key); ?>" <?php echo e(( $key == $selectedID) ? 'selected' : ''); ?>> 
                          <?php echo e($value); ?> 
                      </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
              </select>
                </div>
             
                      <font style="color:red"> <?php echo e($errors->has('janis') ?  $errors->first('janis') : ''); ?> </font>
                  </div>

                  <div class="col-6">
                    <div class="form-group">
                    <label>Container</label>
                    <select class="form-control" name="container_id">
                      <option>Select Container</option>
                      <?php $__currentLoopData = $items_container; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($key); ?>" <?php echo e(( $key == $selected_container) ? 'selected' : ''); ?>> 
                              <?php echo e($value); ?> 
                          </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                  </select>
                    </div>
                 
                          <font style="color:red"> <?php echo e($errors->has('janis') ?  $errors->first('janis') : ''); ?> </font>
                      </div>
              
              <div class="col-6">
                <div class="form-group">
                  <label>Tanggal Transaksi</label>
                    <input type="text" class="form-control datetimepicker" name="tanggal_transaksi"> 
                  
              </div>
               
              </div>
              <div class="col-6">
                <div class="form-group">
                  <label>Tanggal Selesai</label>
                    <input type="text" class="form-control datetimepicker" name="tanggal_selesai"> 
                  
              </div>
               
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Tujuan</label>
                  <textarea class="form-control" 
                        name="tujuan"
                        value="<?php echo e(old('tujuan')); ?>"
                        placeholder="Tujuan"
                        class="form-control" rows="3" required></textarea>
                        <font style="color:red"> <?php echo e($errors->has('tujuan') ?  $errors->first('tujuan') : ''); ?> </font>
                      </div> 
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Detail Barang</label>
                  <textarea class="form-control" 
                        name="barang"
                        value="<?php echo e(old('barang')); ?>"
                        placeholder="detail barang"
                        class="form-control" rows="3"></textarea>
                        <font style="color:red"> <?php echo e($errors->has('barang') ?  $errors->first('barang') : ''); ?> </font>
                      </div> 
              </div>

              <div class="col-12">
                <div class="form-group">
                  <label>Total</label>
                  <br>
                  <input type="text" class="form-control datetimepicker" name="total"> 
                </div> 
              </div>
            
            </div>  

            
            <div class="form-group" style="margin-top: 24px;">
              <input type="submit" class="btn btn-primary" value="Submit">
            </div>

          </form>
        
    </div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lnj-logistik\resources\views/transaction/create.blade.php ENDPATH**/ ?>