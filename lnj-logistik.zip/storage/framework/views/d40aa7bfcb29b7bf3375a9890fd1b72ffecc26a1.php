<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e(config('app.name')); ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script> 
    <!-- CoreUI CSS -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.26.0/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
          integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog=="
          crossorigin="anonymous"/>

    <?php echo $__env->yieldContent('third_party_stylesheets'); ?>

    <?php echo $__env->yieldPushContent('page_css'); ?>
</head>

<body class="c-app">
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="c-wrapper">
    <header class="c-header c-header-light c-header-fixed">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <div class="c-body">
        <main class="c-main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <footer class="c-footer">
        <div><a href="https://coreui.io">Laravel CoreUI</a> © 2022 Demo Hasan Arofid.</div>
        
    </footer>
</div>

<script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.4.0/perfect-scrollbar.js"></script>

<?php echo $__env->yieldContent('third_party_scripts'); ?>

<?php echo $__env->yieldPushContent('page_scripts'); ?>
<?php echo $__env->yieldContent('script'); ?>
<script>
$(function () {
    $('.datetimepicker').datetimepicker();
});
  </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lnj-logistik\resources\views/layouts/app.blade.php ENDPATH**/ ?>