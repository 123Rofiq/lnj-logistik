

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="fade-in">
  <div class="card">
    <div class="card-body">
      <div class="d-flex justify-content-between">
        <div>
        <h4 class="card-title mb-0">Add Container</h4>
        </div>
        <div class="btn-toolbar d-none d-md-block" role="toolbar" aria-label="Toolbar with buttons">
          
        <a href="<?php echo e(route('container.list')); ?>" style="background-color: green;color:white" class="btn  active" > <span class="fa fa-list"></span> list Container</a>
        </div>
        </div>
          <br>
          <?php if(session()->has('message')): ?>
          <p class="btn btn-success btn-block btn-sm custom_message text-left"><?php echo e(session()->get('message')); ?></p>
        <?php endif; ?>
          <form action="<?php echo e(route('container.save')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-12">
                  <div class="form-group">
                      <label>Jenis</label>
                      <input 
                          type="text"
                          name="janis"
                          value="<?php echo e(old('janis')); ?>"
                          placeholder="Jenis Container"
                          class="form-control"
                          required
                      >
                      <font style="color:red"> <?php echo e($errors->has('janis') ?  $errors->first('janis') : ''); ?> </font>
                  </div>
              </div> 
              <div class="col-12">
                <div class="form-group">
                    <label>Dimensi Internal</label>
                    <textarea class="form-control" 
                        name="dimensi_internal"
                        value="<?php echo e(old('dimensi_internal')); ?>"
                        placeholder="Dimensi Internal example : length : 5,000 mm"
                        class="form-control" rows="3" required></textarea>
                    <font style="color:red"> <?php echo e($errors->has('dimensi_internal') ?  $errors->first('dimensi_internal') : ''); ?> </font>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Door Opening</label>
                  <textarea class="form-control" 
                        name="door_opening"
                        value="<?php echo e(old('door_opening')); ?>"
                        placeholder="Door Opening example : length : 5,000 mm "
                        class="form-control" rows="3" required></textarea>
                        <font style="color:red"> <?php echo e($errors->has('door_opening') ?  $errors->first('door_opening') : ''); ?> </font>
                      </div> 
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Weight</label>
                  <textarea class="form-control" 
                        name="weight"
                        value="<?php echo e(old('weight')); ?>"
                        placeholder="weight  example : length : 5,000 mm "
                        class="form-control" rows="3"></textarea>
                        <font style="color:red"> <?php echo e($errors->has('weight') ?  $errors->first('weight') : ''); ?> </font>
                      </div> 
              </div>

              <div class="col-12">
                <div class="form-group">
                  <label>Status</label>
                  <br>
                  <input type="checkbox" name="status" value="1">
                  <label for="vehicle1">Active</label><br>
                </div> 
              </div>
            
            </div>  

            
            <div class="form-group" style="margin-top: 24px;">
              <input type="submit" class="btn btn-primary" value="Submit">
            </div>

          </form>
        
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lnj-logistik\resources\views/container/create.blade.php ENDPATH**/ ?>