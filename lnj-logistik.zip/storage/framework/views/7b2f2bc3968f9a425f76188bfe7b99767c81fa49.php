<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link c-active" href="<?php echo e(route('home')); ?>">
        <i class="c-sidebar-nav-icon cil-home"></i>Home
    </a>
    <a class="c-sidebar-nav-link c-active" href="<?php echo e(route('customer.list')); ?>">
        <i class="c-sidebar-nav-icon fa fa-users"></i>Customer
    </a>
    <a class="c-sidebar-nav-link c-active" href="<?php echo e(route('container.list')); ?>">
        <i class="c-sidebar-nav-icon fa fa-solid fa fa-truck"></i>Container
    </a>
    <a class="c-sidebar-nav-link c-active" href="<?php echo e(route('transaksi.list')); ?>">
        <i class="c-sidebar-nav-icon fa fa-file" ></i> Transaction
        
    </a>

</li>
<?php /**PATH C:\xampp\htdocs\lnj-logistik\resources\views/layouts/menu.blade.php ENDPATH**/ ?>