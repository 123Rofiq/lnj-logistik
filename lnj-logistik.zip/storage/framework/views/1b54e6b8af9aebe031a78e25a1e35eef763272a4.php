

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="fade-in">
  <div class="card">
    <div class="card-body">
      <div class="d-flex justify-content-between">
        <div>
        <h4 class="card-title mb-0">Add Customer</h4>
        </div>
        <div class="btn-toolbar d-none d-md-block" role="toolbar" aria-label="Toolbar with buttons">
          
        <a href="<?php echo e(route('customer.list')); ?>" style="background-color: green;color:white" class="btn  active" > <span class="fa fa-list"></span> list CUSTOMER</a>
        </div>
        </div>
          <br>
        
          <form action="<?php echo e(route('customer.save')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-6">
                  <div class="form-group">
                      <label>Name customer</label>
                      <input 
                          type="text"
                          name="name"
                          value="<?php echo e(old('name')); ?>"
                          placeholder="Form name"
                          class="form-control"
                          required
                      >
                      <font style="color:red"> <?php echo e($errors->has('name') ?  $errors->first('name') : ''); ?> </font>
                  </div>
              </div> 
              <div class="col-6">
                <div class="form-group">
                    <label>Email</label>
                    <input 
                        type="text"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        placeholder="Email"
                        class="form-control"
                        required
                    >
                    <font style="color:red"> <?php echo e($errors->has('email') ?  $errors->first('email') : ''); ?> </font>
                </div>
              </div>
              <div class="col-6">
                <div class="form-group">
                  <label>Email</label>
                  <textarea class="form-control" 
                        name="alamat"
                        value="<?php echo e(old('alamat')); ?>"
                        placeholder="Alamat Customer"
                        class="form-control" rows="3"></textarea>
                        <font style="color:red"> <?php echo e($errors->has('alamat') ?  $errors->first('alamat') : ''); ?> </font>
                      </div> 
              </div>
            </div>  

            
            <div class="form-group" style="margin-top: 24px;">
              <input type="submit" class="btn btn-primary" value="Submit">
            </div>

          </form>
        
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lnj-logistik\resources\views/customer/create.blade.php ENDPATH**/ ?>