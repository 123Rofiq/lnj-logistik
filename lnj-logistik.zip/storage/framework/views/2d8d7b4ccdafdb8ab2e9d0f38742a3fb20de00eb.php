

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="fade-in">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between">
          <div>
          <h4 class="card-title mb-0">View Data Container</h4>
          </div>
          <div class="btn-toolbar d-none d-md-block" role="toolbar" aria-label="Toolbar with buttons">
            
          <a href="<?php echo e(route('container.list')); ?>" style="background-color: green;color:white" class="btn  active" > <span class="fa fa-list"></span> list container</a>
          </div>
          </div>
            <br>
        <div >
          <div class="form-group">
            <label for="">Jenis</label>
            <input type="text" class="form-control" name="janis" readonly value="<?php echo e($container->janis); ?>">
            <font style="color:red"> <?php echo e($errors->has('janis') ?  $errors->first('janis') : ''); ?> </font>
          </div>
          
          <div class="form-group">
            <label>Dimensi Internal</label>
            <textarea class="form-control" 
                name="dimensi_internal"
                value="<?php echo e(old('dimensi_internal')); ?>"
                placeholder="Dimensi Internal example : length : 5,000 mm"
                class="form-control" rows="3" readonly><?php echo e($container->dimensi_internal); ?></textarea>
              <font style="color:red"> <?php echo e($errors->has('dimensi_internal') ?  $errors->first('dimensi_internal') : ''); ?> </font>
          </div>

          <div class="form-group">
            <label>Door Opening</label>
            <textarea class="form-control" 
                  name="door_opening"
                  value="<?php echo e(old('door_opening')); ?>"
                  placeholder="Door Opening example : length : 5,000 mm "
                  class="form-control" rows="3" readonly><?php echo e($container->door_opening); ?></textarea>
                  <font style="color:red"> <?php echo e($errors->has('door_opening') ?  $errors->first('door_opening') : ''); ?> </font>
                </div> 

                <div class="form-group">
                  <label>Weight</label>
                  <textarea class="form-control" 
                        name="weight"
                        value="<?php echo e(old('weight')); ?>"
                        placeholder="weight  example : length : 5,000 mm "
                        class="form-control" rows="3" readonly><?php echo e($container->weight); ?></textarea>
                        <font style="color:red"> <?php echo e($errors->has('weight') ?  $errors->first('weight') : ''); ?> </font>
                      </div> 

                      <div class="form-group">
                        <label>Status</label>
                        <br>
                        <label for="vehicle1"> <?php echo e(($container->status == 1) ? 'Active ' : 'Non Active'); ?></label><br>
                      </div> 
            <div class="form-group" style="margin-top: 24px;">
              <a href="<?php echo e(route('customer.list')); ?>" class="btn btn-success">Back</a>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lnj-logistik\resources\views/container/view.blade.php ENDPATH**/ ?>